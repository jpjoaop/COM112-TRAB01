//COM242 - SISTEMAS DISTRIBUÍDOS (26/04/2023)
const fs = require('fs');

// Função para somar dois números
function soma(req, res) {
  const x = Number(req.params.x);
  const y = Number(req.params.y);
  const result = x + y;
  res.send(`O resultado da soma é: ${result}`);
}

// Função para subtrair dois números
function subtrai(req, res) {
  const x = Number(req.params.x);
  const y = Number(req.params.y);
  const result = x - y;
  res.send(`O resultado da subtração é: ${result}`);
}

// Função para multiplicar dois números
function multiplica(req, res) {
  const x = Number(req.params.x);
  const y = Number(req.params.y);
  const result = x * y;
  res.send(`O resultado da multiplicação é: ${result}`);
}

function msg(req, res) {
  const mensagem = req.params.mensagem;
  res.send(`Mensagem recebida: ${mensagem}`);
}

// Função para alterar o texto do arquivo em caixa alta
function upload(req, res) {
  const file = req.file;
  const filename = file.filename;

  fs.readFile(`uploads/${filename}`, 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Erro ao ler o arquivo.');
    }

    const newData = data.toUpperCase();

    fs.writeFile(`uploads/${filename}`, newData, (err) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Erro ao escrever no arquivo.');
      }

      res.send('Arquivo alterado com sucesso.');
    });
  });
}

// Exporta as funções para serem usadas no arquivo server.js
module.exports = {
  soma,
  subtrai,
  multiplica,
  msg,
  upload,
};

