//COM242 - SISTEMAS DISTRIBUÍDOS (26/04/2023)
const express = require('express');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });

const app = express();

// Importa as funções do arquivo base.js
const base = require('./base');

// Configura as rotas dos serviços
app.get('/soma/:x/:y', base.soma);
app.get('/subtrai/:x/:y', base.subtrai);
app.get('/multiplica/:x/:y', base.multiplica);
app.get('/mensagem/:mensagem', base.msg);
app.get('/upload', (req, res) => {
    res.sendFile(__dirname + '/index.html');
  });

// Rota para upload de arquivo de texto
app.post('/upload', upload.single('file'), base.upload);

// Inicia o servidor na porta 3000
app.listen(3000, () => console.log('Servidor iniciado na porta 3000'));
